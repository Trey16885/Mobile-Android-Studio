from PIL import Image, ImageDraw
import os
S=1024
bg=Image.new("RGB",(S,S))
d=ImageDraw.Draw(bg)
for y in range(S):
    t=y/S; d.line([(0,y),(S,y)],fill=(int(18+10*t),int(32+8*t),int(58+30*t)))
im=bg.convert("RGBA"); d=ImageDraw.Draw(im)
d.rounded_rectangle([292,130,732,894],70,fill=(61,220,132))       # phone
d.rounded_rectangle([322,190,702,830],30,fill=(13,20,36))         # screen
d.rounded_rectangle([462,150,562,170],10,fill=(13,20,36))
d.ellipse([487,845,537,880],fill=(13,20,36))
w=(255,255,255)
def stroke(p,c,wd=38):
    d.line(p,fill=c,width=wd,joint="curve")
    for x,y in (p[0],p[-1]): d.ellipse([x-wd/2,y-wd/2,x+wd/2,y+wd/2],fill=c)
stroke([(445,380),(370,470),(445,560)],w)                         # <
stroke([(579,380),(654,470),(579,560)],w)                         # >
stroke([(540,355),(484,585)],(61,220,132))                        # /
d.polygon([(512,650),(590,695),(512,740),(434,695)],fill=(255,184,76))   # package box
d.polygon([(434,695),(512,740),(512,805),(434,760)],fill=(224,145,44))
d.polygon([(590,695),(512,740),(512,805),(590,760)],fill=(245,166,60))
os.makedirs("app/src/main/res/mipmap-xxxhdpi",exist_ok=True)
im.resize((192,192),Image.LANCZOS).save("app/src/main/res/mipmap-xxxhdpi/ic_launcher.png")
im.resize((512,512),Image.LANCZOS).save("icon_512.png")

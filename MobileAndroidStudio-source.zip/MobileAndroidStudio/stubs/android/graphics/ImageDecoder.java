package android.graphics;
/** Compile-only stub (the real class is on the phone, API 28+). Not packaged. */
public class ImageDecoder {
    public static final int ALLOCATOR_SOFTWARE = 1;
    public static class Source {}
    public static class ImageInfo { public android.util.Size getSize() { return null; } }
    public interface OnHeaderDecodedListener { void onHeaderDecoded(ImageDecoder d, ImageInfo i, Source s); }
    public static Source createSource(android.content.ContentResolver r, android.net.Uri u) { return null; }
    public static Bitmap decodeBitmap(Source s, OnHeaderDecodedListener l) throws java.io.IOException { return null; }
    public void setAllocator(int a) {}
    public void setTargetSampleSize(int n) {}
}

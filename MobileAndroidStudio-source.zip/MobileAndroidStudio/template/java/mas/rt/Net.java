package mas.rt;

import java.io.*;
import java.net.*;
import java.util.*;

/** One HTTP request for Python. No browser CORS rules. */
class Net {
    static String request(String method, String url, String headers, String body64, int millis) {
        try {
            URL u = new URL(url);
            if (!u.getProtocol().equals("http") && !u.getProtocol().equals("https"))
                throw new IOException("Only http and https");
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod(method);
            c.setInstanceFollowRedirects(false);   // urllib and requests follow them themselves
            c.setConnectTimeout(millis);
            c.setReadTimeout(millis);
            for (String line : headers.split("\n")) {
                int i = line.indexOf(':');
                if (i > 0) c.setRequestProperty(line.substring(0, i), line.substring(i + 1).trim());
            }
            if (!body64.isEmpty()) {
                c.setDoOutput(true);
                try (OutputStream o = c.getOutputStream()) {
                    o.write(Base64.getDecoder().decode(body64));
                }
            }
            int code = c.getResponseCode();
            StringBuilder out = new StringBuilder();
            out.append(code).append('\n').append(String.valueOf(c.getResponseMessage())).append('\n');
            for (Map.Entry<String, List<String>> h : c.getHeaderFields().entrySet()) {
                if (h.getKey() == null) continue;
                for (String v : h.getValue()) out.append(h.getKey()).append(": ").append(v).append('\n');
            }
            out.append('\n');
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            if (in != null) {
                byte[] buf = new byte[65536];
                for (int n; (n = in.read(buf)) > 0; ) {
                    bytes.write(buf, 0, n);
                    if (bytes.size() > 20 * 1024 * 1024) throw new IOException("Response is over 20 MB");
                }
                in.close();
            }
            return out.append(Base64.getEncoder().encodeToString(bytes.toByteArray())).toString();
        } catch (Exception e) {
            return "ERR\n" + e;
        }
    }
}

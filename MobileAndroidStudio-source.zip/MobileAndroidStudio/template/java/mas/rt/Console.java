package mas.rt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

/** Native console. Stays responsive while Python keeps the WebView busy. */
class Console {
    private final Activity app;
    private final WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final TextView status, out;
    private final ScrollView scroll;
    private final EditText field;
    private final View keys;
    private final StringBuilder pending = new StringBuilder();
    private final LinkedBlockingQueue<String> lines = new LinkedBlockingQueue<>();
    private final LinkedBlockingQueue<String> presses = new LinkedBlockingQueue<>();
    private final Set<String> held = Collections.synchronizedSet(new HashSet<String>());
    private final Map<String, Long> tapped = new ConcurrentHashMap<>();
    private volatile boolean asking;
    private boolean clearing;
    final View view;

    Console(Activity a, WebView w) {
        app = a;
        web = w;
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(13, 20, 36));
        root.addView(web, new LinearLayout.LayoutParams(1, 1));

        status = text(Color.rgb(61, 220, 132));
        root.addView(status);
        out = text(Color.rgb(230, 237, 247));
        out.setTextIsSelectable(true);
        scroll = new ScrollView(a);
        scroll.addView(out);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout pad = new LinearLayout(a);
        String[][] k = {{"Esc", "esc"}, {"Tab", "tab"}, {"Ctrl", "ctrl"}, {"Shift", "shift"}, {"←", "left"},
                {"↑", "up"}, {"↓", "down"}, {"→", "right"}, {"Space", "space"}, {"Enter", "enter"}, {"⌫", "backspace"}};
        for (String[] key : k) pad.addView(holdKey(key[0], key[1]));
        HorizontalScrollView padScroll = new HorizontalScrollView(a);
        padScroll.addView(pad);
        keys = padScroll;
        keys.setVisibility(View.GONE);
        root.addView(keys);

        field = new EditText(a);
        field.setTextColor(Color.WHITE);
        field.setHintTextColor(Color.GRAY);
        field.setHint("Type here");
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        field.setImeOptions(EditorInfo.IME_ACTION_SEND | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        field.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int id, KeyEvent e) {
                if (e == null || e.getAction() == KeyEvent.ACTION_DOWN) send();
                return true;
            }
        });
        field.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (asking || clearing) return;   // typing an answer, not pressing keys
                for (int i = start; i < start + count; i++)
                    tap(s.charAt(i) == ' ' ? "space" : String.valueOf(s.charAt(i)));
            }
            public void afterTextChanged(Editable s) {}
        });
        root.addView(field);

        LinearLayout bar = new LinearLayout(a);
        bar.addView(button("⌨ Keyboard", new View.OnClickListener() {
            public void onClick(View v) { toggleKeyboard(); }
        }), new LinearLayout.LayoutParams(0, -2, 1));
        bar.addView(button("Send", new View.OnClickListener() {
            public void onClick(View v) { send(); }
        }), new LinearLayout.LayoutParams(0, -2, 1));
        bar.addView(button("Run again", new View.OnClickListener() {
            public void onClick(View v) { app.recreate(); }
        }), new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(bar);
        view = root;
    }

    private TextView text(int color) {
        TextView t = new TextView(app);
        t.setTextColor(color);
        t.setTypeface(Typeface.MONOSPACE);
        t.setPadding(24, 12, 24, 12);
        return t;
    }

    private Button button(String label, View.OnClickListener click) {
        Button b = new Button(app);
        b.setText(label);
        b.setAllCaps(false);
        b.setFocusable(false);
        if (click != null) b.setOnClickListener(click);
        return b;
    }

    private Button holdKey(String label, final String name) {
        Button b = button(label, null);
        b.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    held.add(name);
                    tap(name);
                } else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) {
                    held.remove(name);
                }
                return false;
            }
        });
        return b;
    }

    void tap(String name) {
        tapped.put(name.toLowerCase(Locale.ROOT), SystemClock.uptimeMillis());
        if (presses.size() < 100) presses.add(name);
    }

    private void send() {
        String s = field.getText().toString();
        clearing = true;
        field.setText("");
        clearing = false;
        if (asking) {
            asking = false;
            print(s + "\n");
            lines.add(s);
        } else {
            tap("enter");
        }
    }

    private void showKeyboard() {
        field.requestFocus();
        ui.postDelayed(new Runnable() {
            public void run() {
                ((InputMethodManager) app.getSystemService(Context.INPUT_METHOD_SERVICE))
                        .showSoftInput(field, InputMethodManager.SHOW_IMPLICIT);
            }
        }, 150);
    }

    private void toggleKeyboard() {
        InputMethodManager m = (InputMethodManager) app.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (keys.getVisibility() == View.VISIBLE) {
            keys.setVisibility(View.GONE);
            m.hideSoftInputFromWindow(field.getWindowToken(), 0);
        } else {
            keys.setVisibility(View.VISIBLE);
            showKeyboard();
        }
    }

    private final Runnable flush = new Runnable() {
        public void run() {
            synchronized (pending) {
                out.append(pending);
                pending.setLength(0);
            }
            if (out.length() > 40000) out.setText(out.getText().subSequence(out.length() - 20000, out.length()));
            scroll.post(new Runnable() {
                public void run() { scroll.scrollTo(0, out.getHeight()); }
            });
        }
    };

    private void print(String s) {
        synchronized (pending) {
            boolean idle = pending.length() == 0;
            pending.append(s);
            if (pending.length() > 20000) pending.delete(0, pending.length() - 20000);
            if (idle) ui.postDelayed(flush, 50);
        }
    }

    // ---- called from Python (through python.html) ----

    @JavascriptInterface public void write(String s) { print(s); }

    @JavascriptInterface public void status(final String s) {
        ui.post(new Runnable() {
            public void run() { status.setText(s); }
        });
    }

    /** Blocks Python until the user presses Send. */
    @JavascriptInterface public String input(String prompt) {
        lines.clear();
        asking = true;
        print(prompt);
        ui.post(new Runnable() {
            public void run() { showKeyboard(); }
        });
        try {
            return lines.take();
        } catch (InterruptedException e) {
            return "";
        }
    }

    @JavascriptInterface public void keyboard() {
        ui.post(new Runnable() {
            public void run() { if (keys.getVisibility() != View.VISIBLE) toggleKeyboard(); }
        });
    }

    @JavascriptInterface public boolean pressed(String name) {
        name = name.toLowerCase(Locale.ROOT);
        if (held.contains(name)) return true;
        Long t = tapped.remove(name);   // a tap counts once
        return t != null && SystemClock.uptimeMillis() - t < 500;
    }

    /** Next key press, or "" after the timeout. */
    @JavascriptInterface public String nextKey(int millis) {
        try {
            String k = presses.poll(millis, TimeUnit.MILLISECONDS);
            return k == null ? "" : k;
        } catch (InterruptedException e) {
            return "";
        }
    }

    @JavascriptInterface public String http(String method, String url, String headers, String body, int millis) {
        return Net.request(method, url, headers, body, millis);
    }

    void close() { lines.add(""); }
}

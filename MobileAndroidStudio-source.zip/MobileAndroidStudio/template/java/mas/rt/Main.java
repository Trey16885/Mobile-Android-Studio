package mas.rt;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import java.io.*;

/** Runtime inside every generated APK: shows assets/www in a WebView. */
public class Main extends Activity {
    private static final String HOST = "https://app.local/";
    private WebView web;
    private Console console;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                String url = r.getUrl().toString();
                if (!url.startsWith(HOST)) return null;
                String path = r.getUrl().getPath().substring(1);
                if (path.isEmpty() || path.endsWith("/")) path += "index.html";
                String ext = path.substring(path.lastIndexOf('.') + 1).toLowerCase();
                String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                if (ext.equals("js") || ext.equals("mjs")) mime = "text/javascript";
                if (ext.equals("wasm")) mime = "application/wasm";
                if (ext.equals("json")) mime = "application/json";
                if (mime == null) mime = "text/plain";
                try {
                    return new WebResourceResponse(mime, "UTF-8", getAssets().open("www/" + path));
                } catch (IOException e) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                            null, new ByteArrayInputStream(new byte[0]));
                }
            }
        });
        boolean python;
        try {
            getAssets().open("www/main.py").close();
            getAssets().open("www/mas_rt.py").close();
            python = true;
        } catch (IOException e) {
            python = false;
        }
        if (python) {
            console = new Console(this, web);
            web.addJavascriptInterface(console, "PY");
            setContentView(console.view);
        } else {
            setContentView(web);
        }
        web.loadUrl(HOST + "index.html");
    }

    /** Hardware / Bluetooth keyboards. */
    @Override public boolean dispatchKeyEvent(android.view.KeyEvent e) {
        if (console != null && e.getAction() == android.view.KeyEvent.ACTION_DOWN && e.getDeviceId() > 0) {
            int c = e.getUnicodeChar();
            if (c > 32) console.tap(String.valueOf((char) c));
        }
        return super.dispatchKeyEvent(e);
    }

    @Override protected void onDestroy() {
        if (console != null) console.close();
        web.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}

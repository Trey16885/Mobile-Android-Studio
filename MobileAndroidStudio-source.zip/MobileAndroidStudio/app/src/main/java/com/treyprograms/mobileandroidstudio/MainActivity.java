package com.treyprograms.mobileandroidstudio;

import android.app.Activity;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.util.Base64;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.WindowManager;
import android.webkit.*;
import java.io.*;
import java.util.*;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private Uri picked;
    private String pickedName = "";
    private volatile boolean busy;
    private ValueCallback<Uri[]> chooser;
    private volatile byte[] icon;   // custom launcher icon (PNG) or null

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient() {
            // lets <input type="file"> in the no-code editor open the picker
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback,
                                                       FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = callback;
                try {
                    startActivityForResult(params.createIntent(), 3);
                } catch (ActivityNotFoundException e) {
                    chooser = null;
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "MAS");
        setContentView(web);
        web.loadUrl("file:///android_asset/ui.html");
    }

    private void js(final String call) {
        runOnUiThread(new Runnable() {
            public void run() { web.evaluateJavascript(call, null); }
        });
    }

    private void log(String s) { js("log(" + JSONObject.quote(s) + ")"); }

    class Bridge {
        @JavascriptInterface public void pick() {
            runOnUiThread(new Runnable() {
                public void run() {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("*/*")
                            .addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(i, 1);
                }
            });
        }

        @JavascriptInterface public void pickIcon() {
            runOnUiThread(new Runnable() {
                public void run() {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*")
                            .addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(i, 2);
                }
            });
        }

        @JavascriptInterface public boolean hasToken() { return new TokenStore(MainActivity.this).has(); }

        @JavascriptInterface public void forgetToken() { new TokenStore(MainActivity.this).forget(); }

        @JavascriptInterface public void openGitHub(String page) {
            String url = page.equals("token") ? "https://github.com/settings/personal-access-tokens/new"
                    : "https://github.com/new";
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (ActivityNotFoundException e) {
                log("No browser found. Go to " + url);
            }
        }

        @JavascriptInterface public void clearIcon() { icon = null; }

        @JavascriptInterface public void buildNoCode(final String html, final String variant, final String name) {
            if (busy) return;
            busy = true;
            new Thread(new Runnable() {
                public void run() {
                    try {
                        String title = name.trim().isEmpty() ? "My App" : name.trim();
                        Map<String, byte[]> www = new LinkedHashMap<>();
                        www.put("index.html", html.getBytes("UTF-8"));
                        String safe = title.replaceAll("[^A-Za-z0-9 _-]", "").trim().replace(' ', '_');
                        assemble("nocode", variant, title, safe.isEmpty() ? "app" : safe, www);
                    } catch (Throwable e) {
                        log("ERROR: " + e.getMessage());
                    }
                    busy = false;
                    js("done()");
                }
            }).start();
        }

        @JavascriptInterface public void build(final String mode, final String variant,
                final String name, final String repo, final String token) {
            if (busy) return;
            if (picked == null) { log("Pick a file first."); return; }
            busy = true;
            final Uri uri = picked;
            final String file = pickedName;
            runOnUiThread(new Runnable() {
                public void run() { getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); }
            });
            new Thread(new Runnable() {
                public void run() {
                    try {
                        convert(mode, variant, name.trim(), repo.trim(), token.trim(), uri, file);
                    } catch (Throwable e) {
                        log("ERROR: " + e.getMessage());
                    }
                    busy = false;
                    js("done()");
                }
            }).start();
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == 3) {
            if (chooser != null) chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooser = null;
            return;
        }
        if (res != RESULT_OK || data == null) return;
        if (req == 2) {
            loadIcon(data.getData());
            return;
        }
        picked = data.getData();
        pickedName = "file";
        try (Cursor c = getContentResolver().query(picked, null, null, null, null)) {
            if (c != null && c.moveToFirst())
                pickedName = c.getString(c.getColumnIndex(OpenableColumns.DISPLAY_NAME));
        }
        js("picked(" + JSONObject.quote(pickedName) + ")");
    }

    /** Center-crops the picked image to a square 192x192 PNG. */
    private void loadIcon(Uri uri) {
        try {
            Bitmap src = ImageDecoder.decodeBitmap(ImageDecoder.createSource(getContentResolver(), uri),
                    new ImageDecoder.OnHeaderDecodedListener() {
                        public void onHeaderDecoded(ImageDecoder d, ImageDecoder.ImageInfo info,
                                                    ImageDecoder.Source s) {
                            d.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                            int small = Math.min(info.getSize().getWidth(), info.getSize().getHeight());
                            d.setTargetSampleSize(Math.max(1, small / 384));
                        }
                    });
            int side = Math.min(src.getWidth(), src.getHeight());
            Bitmap square = Bitmap.createBitmap(src, (src.getWidth() - side) / 2, (src.getHeight() - side) / 2,
                    side, side);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            Bitmap.createScaledBitmap(square, 192, 192, true).compress(Bitmap.CompressFormat.PNG, 100, out);
            icon = out.toByteArray();
            js("iconPicked(" + JSONObject.quote("data:image/png;base64,"
                    + Base64.encodeToString(icon, Base64.NO_WRAP)) + ")");
        } catch (Exception e) {
            log("Could not read that image: " + e.getMessage());
        }
    }

    private byte[] asset(String n) throws IOException {
        try (InputStream in = getAssets().open(n)) { return ApkMaker.readAll(in); }
    }

    private void convert(String mode, String variant, String name, String repo, String token,
                     Uri uri, String file) throws Exception {
        String lower = file.toLowerCase(Locale.ROOT);
        boolean ok = mode.equals("studio") ? lower.endsWith(".zip")
                : mode.equals("python") ? lower.endsWith(".py")
                : lower.endsWith(".zip") || lower.endsWith(".html") || lower.endsWith(".htm");
        if (!ok) throw new IOException("Wrong file type for this mode: " + file);
        if (name.isEmpty()) name = file.substring(0, file.lastIndexOf('.'));
        String safe = name.replaceAll("[^A-Za-z0-9 _-]", "").trim().replace(' ', '_');
        if (safe.isEmpty()) safe = "app";
        byte[] data;
        try (InputStream in = getContentResolver().openInputStream(uri)) { data = ApkMaker.readAll(in); }

        if (mode.equals("studio")) {
            if (!repo.matches("[A-Za-z0-9._-]+/[A-Za-z0-9._-]+"))
                throw new IOException("Enter your repo as user/repo");
            TokenStore store = new TokenStore(this);
            if (!token.isEmpty()) {
                store.save(token);
                log("Token saved (encrypted with Android Keystore).");
                js("tokenState()");
            } else {
                token = store.load();
            }
            if (token.isEmpty()) throw new IOException("Enter a GitHub token");
            CloudBuild cloud = new CloudBuild(repo, token, new CloudBuild.Log() {
                public void line(String s) { log(s); }
            });
            byte[] result = cloud.build(asset("mas.yml"), data, variant);
            int n = 0;
            for (Map.Entry<String, byte[]> e : ApkMaker.unzip(result).entrySet()) {
                if (!e.getKey().endsWith(".apk")) continue;
                save(safe + "-" + (++n) + "-" + variant + ".apk", e.getValue());
            }
            return;
        }

        Map<String, byte[]> www;
        if (mode.equals("python")) {
            www = new LinkedHashMap<>();
            www.put("main.py", data);
            www.put("index.html", asset("python.html"));
            www.put("mas_rt.py", asset("mas_rt.py"));
        } else {
            www = ApkMaker.webFiles(data, file);
        }
        assemble(mode, variant, name, safe, www);
    }

    private void assemble(String mode, String variant, String name, String safe,
                          Map<String, byte[]> www) throws Exception {
        log("Building " + variant + " APK...");
        // same name = same package, so rebuilding updates the app
        String pkg = "mas.gen.a" + Integer.toHexString((mode + ":" + name).hashCode()) + "." + variant;
        File out = new File(getCacheDir(), "out.apk");
        ApkMaker.make(asset("template-" + variant + ".apk"), www, name, pkg,
                asset("keys/" + variant + ".pk8"), asset("keys/" + variant + ".x509"), icon, out);
        try (InputStream in = new FileInputStream(out)) {
            save(safe + "-" + variant + ".apk", ApkMaker.readAll(in));
        }
        out.delete();
    }

    private void save(String name, byte[] data) throws IOException {
        ContentValues v = new ContentValues();
        v.put("_display_name", name);
        v.put("mime_type", "application/vnd.android.package-archive");
        v.put("relative_path", "Download/MobileAndroidStudio");
        Uri u = getContentResolver().insert(Uri.parse("content://media/external/downloads"), v);
        if (u == null) throw new IOException("Could not save to Downloads");
        try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(data); }
        log("Saved: Download/MobileAndroidStudio/" + name);
        log("Open it in your Files app to install.");
    }
}

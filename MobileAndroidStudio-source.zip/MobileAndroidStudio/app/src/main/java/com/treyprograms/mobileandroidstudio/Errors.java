package com.treyprograms.mobileandroidstudio;

import java.util.*;

/** Picks the useful lines out of a long build log. */
public class Errors {
    public static String pick(String log) {
        Set<String> found = new LinkedHashSet<>();
        String[] lines = log.split("\n");
        boolean wrong = false;
        int taken = 0;
        for (String raw : lines) {
            String line = raw.replaceFirst("^\uFEFF?\\d{4}-\\d\\d-\\d\\dT[\\d:.]+Z ", "").trim();
            if (line.startsWith("* What went wrong")) { wrong = true; taken = 0; }
            else if (line.startsWith("* Try")) wrong = false;
            boolean important = line.contains(" error:") || line.startsWith("e: ")
                    || line.startsWith("CMake Error") || line.startsWith("> Specified")
                    || line.startsWith("No settings.gradle");
            if (((wrong && taken < 8) || important) && !line.isEmpty() && found.size() < 30) {
                found.add(line.length() > 300 ? line.substring(0, 300) + "..." : line);
                if (wrong) taken++;
            }
        }
        if (found.isEmpty())
            for (int i = Math.max(0, lines.length - 15); i < lines.length; i++) found.add(lines[i].trim());
        StringBuilder out = new StringBuilder("--- why it failed ---");
        for (String s : found) out.append('\n').append(s);
        return out.toString();
    }
}

package com.treyprograms.mobileandroidstudio;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

/** Runs ./gradlew assembleDebug|Release on GitHub Actions and brings the APK back. */
class CloudBuild {
    interface Log { void line(String s); }

    private final String api, token;
    private final Log log;

    CloudBuild(String repo, String token, Log log) {
        this.api = "https://api.github.com/repos/" + repo;
        this.token = token;
        this.log = log;
    }

    private static class Reply { int code; byte[] body; String location; }

    private Reply call(String method, String url, JSONObject json, boolean auth) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setInstanceFollowRedirects(false);
        c.setConnectTimeout(30000);
        c.setReadTimeout(120000);
        c.setRequestProperty("User-Agent", "MobileAndroidStudio");
        if (auth) {
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("Accept", "application/vnd.github+json");
        }
        if (json != null) {
            c.setDoOutput(true);
            try (OutputStream o = c.getOutputStream()) {
                o.write(json.toString().getBytes(StandardCharsets.UTF_8));
            }
        }
        Reply r = new Reply();
        r.code = c.getResponseCode();
        r.location = c.getHeaderField("Location");
        InputStream in = r.code < 400 ? c.getInputStream() : c.getErrorStream();
        r.body = in == null ? new byte[0] : ApkMaker.readAll(in);
        return r;
    }

    private JSONObject json(String method, String path, JSONObject body) throws Exception {
        Reply r = call(method, api + path, body, true);
        String text = new String(r.body, StandardCharsets.UTF_8);
        if (r.code >= 300) throw new IOException("GitHub " + r.code + ": " + text);
        return text.isEmpty() ? new JSONObject() : new JSONObject(text);
    }

    private void put(String path, byte[] data) throws Exception {
        JSONObject body = new JSONObject().put("message", "MAS upload " + path)
                .put("content", android.util.Base64.encodeToString(data, android.util.Base64.NO_WRAP));
        Reply old = call("GET", api + "/contents/" + path, null, true);
        if (old.code == 200)
            body.put("sha", new JSONObject(new String(old.body, StandardCharsets.UTF_8)).getString("sha"));
        json("PUT", "/contents/" + path, body);
    }

    byte[] build(byte[] workflow, byte[] projectZip, String variant) throws Exception {
        String branch = json("GET", "", null).getString("default_branch");
        log.line("Uploading workflow and project...");
        put(".github/workflows/mas.yml", workflow);
        put("project.zip", projectZip);

        String id = UUID.randomUUID().toString().substring(0, 8);
        JSONObject dispatch = new JSONObject().put("ref", branch)
                .put("inputs", new JSONObject().put("variant", variant).put("id", id));
        for (int i = 0; ; i++) {   // a brand-new workflow takes a few seconds to register
            try {
                json("POST", "/actions/workflows/mas.yml/dispatches", dispatch);
                break;
            } catch (IOException e) {
                if (i >= 5) throw e;
                Thread.sleep(5000);
            }
        }
        log.line("Build started (" + variant + "). Usually takes a few minutes...");
        for (int i = 0; i < 180; i++) {
            Thread.sleep(10000);
            JSONArray runs = json("GET", "/actions/workflows/mas.yml/runs?per_page=10", null)
                    .getJSONArray("workflow_runs");
            for (int k = 0; k < runs.length(); k++) {
                JSONObject run = runs.getJSONObject(k);
                if (!run.optString("display_title").equals("mas " + id)) continue;
                if (i % 3 == 0) log.line("Status: " + run.getString("status"));
                if (!run.getString("status").equals("completed")) break;
                if (!run.getString("conclusion").equals("success")) {
                    showErrors(run.getLong("id"));
                    throw new IOException("Build failed. Full log: " + run.getString("html_url"));
                }
                return download(run.getLong("id"));
            }
        }
        throw new IOException("Timed out. Check the Actions tab of your repo.");
    }

    /** Puts Gradle's own explanation in the app log. */
    private void showErrors(long runId) {
        try {
            long job = json("GET", "/actions/runs/" + runId + "/jobs", null)
                    .getJSONArray("jobs").getJSONObject(0).getLong("id");
            Reply r = call("GET", api + "/actions/jobs/" + job + "/logs", null, true);
            if (r.location != null) r = call("GET", r.location, null, false);
            if (r.code == 200) log.line(Errors.pick(new String(r.body, StandardCharsets.UTF_8)));
        } catch (Exception e) {
            log.line("(Could not fetch the error details: " + e.getMessage() + ")");
        }
    }

    private byte[] download(long runId) throws Exception {
        long artifact = json("GET", "/actions/runs/" + runId + "/artifacts", null)
                .getJSONArray("artifacts").getJSONObject(0).getLong("id");
        Reply r = call("GET", api + "/actions/artifacts/" + artifact + "/zip", null, true);
        if (r.location != null) r = call("GET", r.location, null, false);   // never send the token along
        if (r.code != 200) throw new IOException("Download failed: " + r.code);
        return r.body;
    }
}

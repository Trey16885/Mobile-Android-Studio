package com.treyprograms.mobileandroidstudio;

import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.X509Certificate;

/** APK Signature Scheme v2 (RSA + SHA-256). No libraries, no lambdas. */
class ApkSignerV2 {
    private static final int ALG = 0x0103;

    static byte[] sign(byte[] zip, PrivateKey key, X509Certificate cert) throws Exception {
        int eocd = zip.length - 22;   // our zips have no comment
        ByteBuffer in = ByteBuffer.wrap(zip).order(ByteOrder.LITTLE_ENDIAN);
        if (in.getInt(eocd) != 0x06054b50) throw new IOException("Bad zip");
        int cd = in.getInt(eocd + 16);

        // digest of: entries, central directory, end record (1 MB chunks)
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        ByteArrayOutputStream chunks = new ByteArrayOutputStream();
        int[][] parts = {{0, cd}, {cd, eocd}, {eocd, zip.length}};
        int count = 0;
        for (int[] p : parts) {
            for (int at = p[0]; at < p[1]; at += 1 << 20) {
                int len = Math.min(1 << 20, p[1] - at);
                sha.update((byte) 0xa5);
                sha.update(le32(len));
                sha.update(zip, at, len);
                chunks.write(sha.digest());
                count++;
            }
        }
        sha.update((byte) 0x5a);
        sha.update(le32(count));
        byte[] digest = sha.digest(chunks.toByteArray());

        byte[] signedData = cat(
                lp(lp(cat(le32(ALG), lp(digest)))),
                lp(lp(cert.getEncoded())),
                lp(new byte[0]));
        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(key);
        s.update(signedData);
        byte[] signer = cat(
                lp(signedData),
                lp(lp(cat(le32(ALG), lp(s.sign())))),
                lp(cert.getPublicKey().getEncoded()));
        byte[] value = lp(lp(signer));

        long size = 8 + 4 + value.length + 8 + 16;
        byte[] block = cat(le64(size), le64(4 + value.length), le32(0x7109871a), value,
                le64(size), "APK Sig Block 42".getBytes(StandardCharsets.US_ASCII));

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(zip, 0, cd);
        out.write(block);
        out.write(zip, cd, eocd - cd);
        byte[] end = java.util.Arrays.copyOfRange(zip, eocd, zip.length);
        ByteBuffer.wrap(end).order(ByteOrder.LITTLE_ENDIAN).putInt(16, cd + block.length);
        out.write(end);
        return out.toByteArray();
    }

    private static byte[] le32(int v) {
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array();
    }

    private static byte[] le64(long v) {
        return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(v).array();
    }

    private static byte[] lp(byte[] b) throws IOException {
        return cat(le32(b.length), b);
    }

    private static byte[] cat(byte[]... all) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (byte[] a : all) o.write(a);
        return o.toByteArray();
    }
}

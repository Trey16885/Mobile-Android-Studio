package com.treyprograms.mobileandroidstudio;

import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.zip.*;

/** Builds an APK on the phone: template + your files + new name, then sign. Plain Java. */
public class ApkMaker {

    public static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        long total = 0;
        for (int n; (n = in.read(buf)) > 0; ) {
            total += n;
            if (total > 150L * 1024 * 1024) throw new IOException("File is too big (150 MB limit)");
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    public static Map<String, byte[]> unzip(byte[] zip) throws IOException {
        Map<String, byte[]> files = new LinkedHashMap<>();
        long total = 0;
        try (ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(zip))) {
            for (ZipEntry e; (e = z.getNextEntry()) != null; ) {
                String n = e.getName().replace('\\', '/');
                if (e.isDirectory() || n.startsWith("/") || n.startsWith("__MACOSX/")
                        || ("/" + n + "/").contains("/../")) continue;
                byte[] data = readAll(z);
                total += data.length;
                if (total > 200L * 1024 * 1024) throw new IOException("Zip is too big when unpacked");
                files.put(n, data);
            }
        }
        return files;
    }

    /** Files for assets/www. Makes sure index.html exists at the top level. */
    public static Map<String, byte[]> webFiles(byte[] data, String name) throws IOException {
        Map<String, byte[]> files = new LinkedHashMap<>();
        if (!name.toLowerCase().endsWith(".zip")) {
            files.put("index.html", data);
            return files;
        }
        files = unzip(data);
        if (files.isEmpty()) throw new IOException("That zip is empty or not a zip");
        String root = null;   // folder of the shallowest index.html
        for (String n : files.keySet()) {
            if (n.equals("index.html") || n.endsWith("/index.html")) {
                String dir = n.substring(0, n.length() - "index.html".length());
                if (root == null || dir.length() < root.length()) root = dir;
            }
        }
        if (root != null) {
            Map<String, byte[]> moved = new LinkedHashMap<>();
            for (Map.Entry<String, byte[]> e : files.entrySet())
                if (e.getKey().startsWith(root)) moved.put(e.getKey().substring(root.length()), e.getValue());
            return moved;
        }
        StringBuilder list = new StringBuilder("<!doctype html><meta charset=utf-8><meta name=viewport "
                + "content='width=device-width'><body style='font:18px sans-serif'><h3>Files</h3>");
        for (String n : files.keySet()) {
            String safe = n.replace("&", "&amp;").replace("<", "&lt;").replace("\"", "&quot;");
            String href = safe.replace("%", "%25").replace("#", "%23").replace("?", "%3F");
            list.append("<p><a href=\"./").append(href).append("\">").append(safe).append("</a></p>");
        }
        files.put("index.html", list.toString().getBytes(StandardCharsets.UTF_8));
        return files;
    }

    /** Rewrites strings in a compiled AndroidManifest.xml (resizes the string pool). */
    static byte[] patchManifest(byte[] xml, Map<String, String> swaps) throws IOException {
        ByteBuffer b = ByteBuffer.wrap(xml).order(ByteOrder.LITTLE_ENDIAN);
        int pool = 8, size = b.getInt(pool + 4), count = b.getInt(pool + 8);
        int flags = b.getInt(pool + 16), start = b.getInt(pool + 20);
        if (b.getShort(pool) != 1 || b.getInt(pool + 12) != 0) throw new IOException("Unexpected manifest");
        boolean utf8 = (flags & 0x100) != 0;
        ByteArrayOutputStream strings = new ByteArrayOutputStream();
        int[] offsets = new int[count];
        for (int i = 0; i < count; i++) {
            int p = pool + start + b.getInt(pool + 28 + i * 4);
            String s;
            if (utf8) {
                p += (xml[p] & 0x80) != 0 ? 2 : 1;
                int len = xml[p++] & 0xff;
                if ((len & 0x80) != 0) len = ((len & 0x7f) << 8) | (xml[p++] & 0xff);
                s = new String(xml, p, len, StandardCharsets.UTF_8);
            } else {
                s = new String(xml, p + 2, (b.getShort(p) & 0xffff) * 2, StandardCharsets.UTF_16LE);
            }
            if (swaps.containsKey(s)) s = swaps.get(s);
            offsets[i] = strings.size();
            if (utf8) {
                byte[] d = s.getBytes(StandardCharsets.UTF_8);
                writeLen8(strings, s.length());
                writeLen8(strings, d.length);
                strings.write(d);
                strings.write(0);
            } else {
                strings.write(s.length() & 0xff);
                strings.write(s.length() >> 8);
                strings.write(s.getBytes(StandardCharsets.UTF_16LE));
                strings.write(0);
                strings.write(0);
            }
        }
        while (strings.size() % 4 != 0) strings.write(0);
        int newStart = 28 + count * 4, newSize = newStart + strings.size();
        ByteBuffer o = ByteBuffer.allocate(xml.length - size + newSize).order(ByteOrder.LITTLE_ENDIAN);
        o.put(xml, 0, 8);
        o.putInt(b.getInt(pool)).putInt(newSize).putInt(count).putInt(0)
                .putInt(flags & ~1).putInt(newStart).putInt(0);
        for (int off : offsets) o.putInt(off);
        o.put(strings.toByteArray());
        o.put(xml, pool + size, xml.length - pool - size);
        o.putInt(4, o.capacity());
        return o.array();
    }

    private static void writeLen8(OutputStream o, int n) throws IOException {
        if (n > 127) o.write((n >> 8) | 0x80);
        o.write(n & 0xff);
    }

    /** resources.arsc must be stored uncompressed and 4-byte aligned on Android 11+. */
    private static class Zipper {
        final ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        final ZipOutputStream zip = new ZipOutputStream(bytes);

        void add(String name, byte[] data) throws IOException {
            ZipEntry e = new ZipEntry(name);
            if (name.equals("resources.arsc")) {
                CRC32 crc = new CRC32();
                crc.update(data);
                e.setMethod(ZipEntry.STORED);
                e.setSize(data.length);
                e.setCrc(crc.getValue());
                zip.flush();
                int dataAt = bytes.size() + 30 + name.length();
                int pad = (4 - dataAt % 4) % 4;
                if (pad != 0) {          // a well-formed extra field of length pad+4
                    byte[] x = new byte[pad + 4];
                    x[0] = 0x35; x[1] = (byte) 0xd9; x[2] = (byte) pad;
                    e.setExtra(x);
                }
            }
            zip.putNextEntry(e);
            zip.write(data);
            zip.closeEntry();
        }
    }

    public static void make(byte[] template, Map<String, byte[]> www, String label, String pkg,
                            byte[] pk8, byte[] cert, byte[] icon, File out) throws Exception {
        Zipper z = new Zipper();
        Map<String, String> swaps = new HashMap<>();
        swaps.put("mas.gen.template", pkg);
        swaps.put("MAS_LABEL", label);
        for (Map.Entry<String, byte[]> e : unzip(template).entrySet()) {
            if (e.getKey().startsWith("META-INF/")) continue;
            byte[] data = e.getValue();
            if (e.getKey().equals("AndroidManifest.xml")) data = patchManifest(data, swaps);
            if (icon != null && e.getKey().endsWith("/ic_launcher.png")) data = icon;
            z.add(e.getKey(), data);
        }
        for (Map.Entry<String, byte[]> e : www.entrySet()) z.add("assets/www/" + e.getKey(), e.getValue());
        z.zip.close();

        PrivateKey key = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(pk8));
        X509Certificate x509 = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(cert));
        try (FileOutputStream f = new FileOutputStream(out)) {
            f.write(ApkSignerV2.sign(z.bytes.toByteArray(), key, x509));
        }
    }
}

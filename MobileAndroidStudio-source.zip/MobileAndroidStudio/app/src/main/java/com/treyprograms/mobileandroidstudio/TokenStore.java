package com.treyprograms.mobileandroidstudio;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** GitHub token, encrypted with an AES key that never leaves Android Keystore. */
class TokenStore {
    private static final String ALIAS = "mas_github_token";
    private final SharedPreferences prefs;

    TokenStore(Context c) {
        prefs = c.getSharedPreferences("secure", Context.MODE_PRIVATE);
    }

    private SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (store.containsAlias(ALIAS)) return (SecretKey) store.getKey(ALIAS, null);
        KeyGenerator g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        g.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return g.generateKey();
    }

    boolean has() {
        return prefs.contains("data");
    }

    void save(String token) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key());
        byte[] data = c.doFinal(token.getBytes(StandardCharsets.UTF_8));
        prefs.edit().putString("iv", Base64.encodeToString(c.getIV(), Base64.NO_WRAP))
                .putString("data", Base64.encodeToString(data, Base64.NO_WRAP)).apply();
    }

    /** Saved token, or "" if there is none. */
    String load() throws Exception {
        if (!has()) return "";
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key(),
                new GCMParameterSpec(128, Base64.decode(prefs.getString("iv", ""), Base64.NO_WRAP)));
        byte[] data = Base64.decode(prefs.getString("data", ""), Base64.NO_WRAP);
        return new String(c.doFinal(data), StandardCharsets.UTF_8);
    }

    void forget() {
        prefs.edit().clear().apply();
    }
}

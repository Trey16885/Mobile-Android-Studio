"""Phone support: input(), key-press stand-ins and finding packages to pip install."""
import base64, builtins, email.message, importlib, importlib.util, io, sys, time, types
import urllib.error, urllib.request, urllib.response
from js import PY
from pyodide.code import find_imports

KEY_LIBS = {"keyboard", "msvcrt", "pynput"}
PIP_NAMES = {"PIL": "pillow", "cv2": "opencv-python", "bs4": "beautifulsoup4", "sklearn": "scikit-learn",
             "yaml": "pyyaml", "dotenv": "python-dotenv", "dateutil": "python-dateutil",
             "Crypto": "pycryptodome", "serial": "pyserial", "docx": "python-docx", "pptx": "python-pptx"}
NEVER = {"tkinter", "turtle", "curses", "js", "pyodide", "mas_rt"}
_handlers = []  # (key or None, callback)


def _input(prompt=""):
    sys.stdout.flush()
    return str(PY.input(str(prompt)))


def _next(ms=50):
    key = str(PY.nextKey(ms))
    if key:
        for want, call in list(_handlers):
            if want is None or want == key.lower():
                call(key)
    return key


def _module(name, **items):
    mod = types.ModuleType(name)
    mod.__dict__.update(items)
    sys.modules[name] = mod
    return mod


# ---- keyboard ----
class _Event:
    def __init__(self, name):
        self.name, self.event_type = name, "down"


def _is_pressed(key):
    _next(1)
    return all(PY.pressed(k.strip()) for k in str(key).split("+"))


def _read_key():
    while True:
        key = _next()
        if key:
            return key


def _wait(key=None):
    while True:
        got = _next()
        if key and got.lower() == key.lower():
            return


def _add_hotkey(key, callback, args=()):
    _handlers.append((key.lower(), lambda _: callback(*args)))


def _on_press(callback):
    _handlers.append((None, lambda k: callback(_Event(k))))


def _on_press_key(key, callback):
    _handlers.append((key.lower(), lambda k: callback(_Event(k))))


# ---- msvcrt ----
_buffer = []
_CHARS = {"enter": "\r", "space": " ", "esc": "\x1b", "tab": "\t", "backspace": "\b"}


def _kbhit():
    if not _buffer:
        key = _next(1)
        if key and (len(key) == 1 or key in _CHARS):
            _buffer.append(_CHARS.get(key, key))
    return bool(_buffer)


def _getwch():
    while not _kbhit():
        time.sleep(0.01)
    return _buffer.pop(0)


# ---- pynput.keyboard ----
class _Key:
    def __init__(self, name):
        self.name = name

    def __eq__(self, other):
        return isinstance(other, _Key) and other.name == self.name

    def __hash__(self):
        return hash(self.name)


class _Keys:
    esc, space, enter, tab, backspace = map(_Key, ["esc", "space", "enter", "tab", "backspace"])
    up, down, left, right = map(_Key, ["up", "down", "left", "right"])
    shift, ctrl = _Key("shift"), _Key("ctrl")


class _KeyCode:
    def __init__(self, char):
        self.char = char

    def __eq__(self, other):
        return isinstance(other, _KeyCode) and other.char == self.char

    def __hash__(self):
        return hash(self.char)

    def __str__(self):
        return repr(self.char)

    @classmethod
    def from_char(cls, char):
        return cls(char)


class _Listener:
    def __init__(self, on_press=None, on_release=None, **_):
        self.on_press, self.on_release, self.running = on_press, on_release, False

    def start(self):
        self.running = True

    def stop(self):
        self.running = False

    def join(self):
        self.running = True
        while self.running:
            name = _next()
            if not name:
                continue
            key = _KeyCode(name) if len(name) == 1 else getattr(_Keys, name, _Key(name))
            for call in (self.on_press, self.on_release):
                if call and call(key) is False:
                    self.running = False

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *_):
        self.running = False


def setup(code):
    builtins.input = _input
    _module("keyboard", is_pressed=_is_pressed, read_key=_read_key, wait=_wait, add_hotkey=_add_hotkey,
            on_press=_on_press, on_press_key=_on_press_key)
    _module("msvcrt", kbhit=_kbhit, getwch=_getwch, getch=lambda: _getwch().encode())
    board = _module("pynput.keyboard", Key=_Keys, KeyCode=_KeyCode, Listener=_Listener)
    _module("pynput", keyboard=board)
    if KEY_LIBS & set(find_imports(code)):
        PY.keyboard()


def missing(code):
    """pip names for imports that are not available yet."""
    importlib.invalidate_caches()
    out = []
    for name in find_imports(code):
        top = name.split(".")[0]
        if top in NEVER or top in sys.stdlib_module_names or top in sys.modules:
            continue
        if importlib.util.find_spec(top) is None:
            pip = PIP_NAMES.get(top, top)
            if pip not in out:
                out.append(pip)
    return out


# ---- network: urllib and requests go through Android, so there is no CORS ----
def _http(method, url, headers, body, timeout):
    if hasattr(body, "read"):
        body = body.read()
    if isinstance(body, str):
        body = body.encode()
    elif body is not None and not isinstance(body, (bytes, bytearray)):
        body = b"".join(body)
    lines = "".join(f"{k}: {v.decode() if isinstance(v, bytes) else v}\n" for k, v in headers.items()
                    if k.lower() not in ("accept-encoding", "content-length", "connection", "host"))
    millis = int(timeout * 1000) if isinstance(timeout, (int, float)) else 30000
    reply = str(PY.http(method, url, lines, base64.b64encode(body or b"").decode(), millis))
    if reply.startswith("ERR\n"):
        raise OSError(reply[4:])
    head, data = reply.split("\n\n", 1)
    status, reason, *rest = head.split("\n")
    message = email.message.Message()
    for line in rest:
        key, value = line.split(": ", 1)
        message[key] = value
    return int(status), reason, message, base64.b64decode(data)


class _Handler(urllib.request.BaseHandler):
    handler_order = 100  # ahead of the socket-based handlers

    def http_open(self, req):
        headers = dict(req.header_items())
        if req.data is not None and "Content-type" not in headers:
            headers["Content-type"] = "application/x-www-form-urlencoded"
        try:
            code, reason, message, data = _http(req.get_method(), req.full_url, headers, req.data, req.timeout)
        except OSError as e:
            raise urllib.error.URLError(e)
        response = urllib.response.addinfourl(io.BytesIO(data), message, req.full_url, code)
        response.msg = reason
        return response

    https_open = http_open


def network():
    urllib.request.install_opener(urllib.request.build_opener(_Handler()))
    if importlib.util.find_spec("requests") is None:
        return
    import requests

    def send(adapter, request, stream=False, timeout=None, **_):
        if isinstance(timeout, tuple):
            timeout = timeout[1]
        try:
            code, reason, message, data = _http(request.method, request.url, request.headers, request.body, timeout)
        except OSError as e:
            raise requests.ConnectionError(e, request=request)
        r = requests.Response()
        r.status_code, r.reason, r.url, r.request = code, reason, request.url, request
        for key in message.keys():
            r.headers[key] = ", ".join(message.get_all(key))
        r.encoding = requests.utils.get_encoding_from_headers(r.headers)
        r.raw = io.BytesIO(data)
        r.raw._original_response = types.SimpleNamespace(msg=message)
        requests.cookies.extract_cookies_to_jar(r.cookies, request, r.raw)
        return r

    requests.adapters.HTTPAdapter.send = send


def finish():
    # a script that only registered key callbacks keeps listening
    if _handlers:
        PY.status("Listening for keys...")
        while True:
            _next()

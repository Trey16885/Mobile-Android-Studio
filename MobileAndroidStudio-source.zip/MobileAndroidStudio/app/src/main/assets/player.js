// Runs a no-code project. Used by the preview AND copied into every built app.
function player(P) {
  const key = "mas-save", vals = {}, views = [];
  const el = (tag, css, text) => { const e = document.createElement(tag); e.style.cssText = css || ""; if (text != null) e.textContent = text; return e; };
  const stored = P.items.filter(i => i.type === "counter" || i.type === "variable" || i.type === "input");
  const reset = n => { const i = stored.find(x => x.name === n); if (i) vals[n] = String(i.start || (i.type === "counter" ? 0 : "")); };
  stored.forEach(i => reset(i.name));
  if (P.remember) { try { const old = JSON.parse(localStorage.getItem(key)) || {}; for (const n in vals) if (n in old) vals[n] = old[n]; } catch (e) {} }
  const num = v => Number(v) || 0;
  const fill = t => String(t || "").replace(/\{([^{}]+)\}/g, (m, n) => n in vals ? vals[n] : m);
  function refresh() {
    P.items.forEach(i => { if (i.type === "variable" && i.follow in vals) vals[i.name] = String(num(vals[i.follow]) * num(i.times === "" || i.times == null ? 1 : i.times) + num(i.plus)); });
    views.forEach(f => f());
    if (P.remember) { try { localStorage.setItem(key, JSON.stringify(vals)); } catch (e) {} }
  }
  const toast = el("div", "position:fixed;left:16px;right:16px;bottom:24px;background:#000d;color:#fff;padding:14px;border-radius:12px;text-align:center;display:none");
  let timer;
  function act(a) {
    if (a.do === "message") { toast.textContent = fill(a.value); toast.style.display = ""; clearTimeout(timer); timer = setTimeout(() => toast.style.display = "none", 2000); return; }
    if (!(a.target in vals)) return;
    if (a.do === "add") vals[a.target] = String(Math.round((num(vals[a.target]) + num(fill(a.value))) * 1e6) / 1e6);
    if (a.do === "set") vals[a.target] = fill(a.value);
    if (a.do === "reset") reset(a.target);
  }
  const press = i => () => { (i.actions || []).forEach(a => { act(a); refresh(); }); };
  document.body.style.cssText = "margin:0;padding:20px;font-family:sans-serif;text-align:center;background:" + (P.bg || "#0d1424") + ";color:" + (P.fg || "#ffffff");
  document.body.textContent = "";
  P.items.forEach(i => {
    const box = el("div", "margin:14px 0");
    if (i.type === "text") { const t = el("div", "white-space:pre-wrap;font-size:" + (num(i.size) || 20) + "px"); views.push(() => t.textContent = fill(i.text)); box.append(t); }
    if (i.type === "counter" || (i.type === "variable" && i.show)) {
      const t = el("div", "font-size:" + (i.type === "counter" ? 34 : 20) + "px;font-weight:bold");
      views.push(() => t.textContent = (i.label ? i.label + ": " : "") + vals[i.name]); box.append(t);
    }
    if (i.type === "input") {
      const f = el("input", "font-size:18px;padding:12px;width:100%;box-sizing:border-box;border-radius:10px;border:0");
      f.placeholder = i.label || ""; f.oninput = () => { vals[i.name] = f.value; refresh(); };
      views.push(() => { if (f.value !== vals[i.name]) f.value = vals[i.name]; }); box.append(f);
    }
    if (i.type === "button") {
      const b = el("button", "font-size:20px;padding:14px 28px;border:0;border-radius:12px;color:#fff;background:" + (i.color || "#2f7df6"));
      views.push(() => b.textContent = fill(i.label) || "Button"); b.onclick = press(i); box.append(b);
    }
    if (i.type === "image" || i.type === "imagebutton") {
      const m = el("img", "max-width:100%;width:" + (num(i.width) || 200) + "px;touch-action:manipulation"); m.src = i.src || ""; m.alt = i.type;
      if (i.type === "imagebutton") {
        m.onclick = press(i);
        m.onpointerdown = () => m.style.transform = "scale(.93)";
        m.onpointerup = m.onpointercancel = m.onpointerleave = () => m.style.transform = "";
      }
      box.append(m);
    }
    if (box.childNodes.length) document.body.append(box);
  });
  document.body.append(toast);
  refresh();
}

function appHtml(project) {
  const data = JSON.stringify(project).replace(/</g, "\\u003c");
  return '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body><script>(' +
    player + ')(' + data + ')<\/script>';
}

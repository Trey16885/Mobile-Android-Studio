// The no-code editor.
const NC = (() => {
  const KEY = "mas-nocode";
  const blank = () => ({bg: "#0d1424", fg: "#ffffff", remember: true, items: []});
  let P = blank();
  try { P = JSON.parse(localStorage.getItem(KEY)) || P; } catch (e) {}
  const root = document.getElementById("nocode");
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(P)); } catch (e) { log("Project too big to auto-save. Use smaller or fewer images."); } };
  const h = (tag, props, ...kids) => { const e = Object.assign(document.createElement(tag), props); e.append(...kids); return e; };
  const names = () => P.items.filter(i => ["counter", "variable", "input"].includes(i.type)).map(i => i.name);
  const labels = {text: "📝 Text", button: "🔘 Button", imagebutton: "🖼️ Image button", image: "🌄 Image", counter: "🔢 Counter", variable: "📦 Variable", input: "⌨️ Text box"};
  const fresh = base => { let n = 1; while (names().includes(base + n)) n++; return base + n; };

  function add(type) {
    const i = {type};
    if (type === "counter") Object.assign(i, {name: fresh("counter"), start: "0", label: "Score"});
    if (type === "variable") Object.assign(i, {name: fresh("var"), start: "", label: "", show: false, follow: "", times: "1", plus: "0"});
    if (type === "input") Object.assign(i, {name: fresh("text"), start: "", label: "Type here"});
    if (type === "text") Object.assign(i, {text: "Hello!", size: "24"});
    if (type === "button") Object.assign(i, {label: "Tap me", color: "#2f7df6", actions: []});
    if (type === "imagebutton") Object.assign(i, {src: "", width: "180", actions: []});
    if (type === "image") Object.assign(i, {src: "", width: "220"});
    P.items.push(i); draw();
  }

  function field(label, obj, prop, type = "text") {
    const input = h("input", {type});
    if (type === "checkbox") { input.checked = !!obj[prop]; input.onchange = () => { obj[prop] = input.checked; save(); }; }
    else { input.value = obj[prop] ?? ""; input.oninput = () => { obj[prop] = input.value; save(); }; }
    return h("label", {}, label, input);
  }

  function select(label, value, options, change) {
    const s = h("select", {});
    options.forEach(([v, t]) => s.append(h("option", {value: v, textContent: t})));
    s.value = value; s.onchange = () => change(s.value);
    return h("label", {}, label, s);
  }

  function nameField(item) {
    const input = h("input", {value: item.name});
    input.onchange = () => {
      const next = input.value.replace(/[{}]/g, "").trim(), old = item.name;
      if (!next || (next !== old && names().includes(next))) { input.value = old; log("That name is empty or already used."); return; }
      item.name = next;
      P.items.forEach(i => {                       // keep links pointing at the renamed item
        if (i.follow === old) i.follow = next;
        (i.actions || []).forEach(a => { if (a.target === old) a.target = next; a.value = String(a.value ?? "").split("{" + old + "}").join("{" + next + "}"); });
        ["text", "label"].forEach(k => { if (i[k]) i[k] = i[k].split("{" + old + "}").join("{" + next + "}"); });
      });
      draw();
    };
    return h("label", {}, "Name (use as {name})", input);
  }

  function picture(item) {
    const file = h("input", {type: "file", accept: "image/*"});
    file.onchange = () => {
      const img = new Image(), url = URL.createObjectURL(file.files[0]);
      img.onload = () => {
        const k = Math.min(1, 400 / Math.max(img.width, img.height));
        const c = h("canvas", {width: Math.round(img.width * k), height: Math.round(img.height * k)});
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        item.src = c.toDataURL("image/png"); URL.revokeObjectURL(url); draw();
      };
      img.onerror = () => log("Could not read that image.");
      img.src = url;
    };
    const box = h("label", {}, "Picture", file);
    if (item.src) box.append(h("img", {src: item.src, className: "thumb"}));
    return box;
  }

  function actions(item) {
    const box = h("div", {className: "acts"}, h("b", {textContent: "When tapped:"}));
    item.actions.forEach((a, n) => {
      const row = h("div", {className: "act"});
      row.append(select("Do", a.do, [["add", "Add to (use -1 to subtract)"], ["set", "Set"], ["reset", "Reset"], ["message", "Show message"]], v => { a.do = v; draw(); }));
      if (a.do !== "message") row.append(select("Which", a.target, [["", "(choose)"], ...names().map(x => [x, x])], v => { a.target = v; save(); }));
      if (a.do !== "reset") row.append(field(a.do === "message" ? "Message" : "Value", a, "value"));
      row.append(h("button", {textContent: "Remove action", onclick: () => { item.actions.splice(n, 1); draw(); }}));
      box.append(row);
    });
    box.append(h("button", {textContent: "+ Add action", onclick: () => { item.actions.push({do: "add", target: names()[0] || "", value: "1"}); draw(); }}));
    return box;
  }

  function card(item, n) {
    const move = d => () => { const j = n + d; if (j < 0 || j >= P.items.length) return; [P.items[n], P.items[j]] = [P.items[j], P.items[n]]; draw(); };
    const c = h("div", {className: "card"}, h("div", {className: "row"},
      h("b", {textContent: labels[item.type]}),
      h("button", {textContent: "↑", onclick: move(-1)}), h("button", {textContent: "↓", onclick: move(1)}),
      h("button", {textContent: "✕", onclick: () => { if (confirm("Delete this?")) { P.items.splice(n, 1); draw(); } }})));
    const t = item.type;
    if (item.name !== undefined) c.append(nameField(item));
    if (t === "text") c.append(field("Text (put {name} to show a value)", item, "text"), field("Size", item, "size", "number"));
    if (t === "counter") {
      c.append(field("Label", item, "label"), field("Starts at", item, "start", "number"));
      const linked = P.items.filter(i => (i.actions || []).some(a => a.target === item.name)).map(i => i.label || labels[i.type]);
      c.append(h("small", {textContent: "Linked buttons: " + (linked.join(", ") || "none yet")}));
      [["+1 button", "1"], ["-1 button", "-1"]].forEach(([text, v]) => c.append(h("button", {textContent: "Make a " + text,
        onclick: () => { P.items.push({type: "button", label: (v === "1" ? "+1 " : "-1 ") + item.name, color: "#2f7df6", actions: [{do: "add", target: item.name, value: v}]}); draw(); }})));
    }
    if (t === "variable") {
      c.append(field("Starting value", item, "start"), field("Label", item, "label"), field("Show on screen", item, "show", "checkbox"));
      c.append(select("Follow a counter", item.follow, [["", "No"], ...P.items.filter(i => i.type === "counter").map(i => [i.name, i.name])], v => { item.follow = v; draw(); }));
      if (item.follow) c.append(field("Multiply by", item, "times", "number"), field("Then add", item, "plus", "number"));
    }
    if (t === "input") c.append(field("Hint", item, "label"), field("Starting value", item, "start"));
    if (t === "button") c.append(field("Label", item, "label"), field("Color", item, "color", "color"), actions(item));
    if (t === "image" || t === "imagebutton") c.append(picture(item), field("Width", item, "width", "number"));
    if (t === "imagebutton") c.append(actions(item));
    return c;
  }

  function draw() {
    save();
    root.textContent = "";
    const adds = h("div", {className: "grid"});
    Object.entries(labels).forEach(([type, text]) => adds.append(h("button", {textContent: "+ " + text, onclick: () => add(type)})));
    root.append(adds);
    P.items.forEach((item, n) => root.append(card(item, n)));
    root.append(field("Background", P, "bg", "color"), field("Text color", P, "fg", "color"),
      field("Remember values after closing the app", P, "remember", "checkbox"));
    const frame = h("iframe", {className: "preview", sandbox: "allow-scripts"});
    root.append(h("div", {className: "row"},
      h("button", {textContent: "▶ Preview / restart", onclick: () => { frame.style.display = "block"; frame.srcdoc = appHtml({...P, remember: false}); frame.scrollIntoView(); }}),
      h("button", {textContent: "🗑️ New project", onclick: () => { if (confirm("Erase this no-code project?")) { P = blank(); draw(); } }})), frame);
  }

  draw();
  return {html: () => P.items.length ? appHtml(P) : null};
})();

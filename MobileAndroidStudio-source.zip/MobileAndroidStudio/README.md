# Mobile Android Studio

| Mode | Input | Where it builds |
|---|---|---|
| Studio project | .zip of a Gradle project | GitHub Actions (`./gradlew assembleDebug` / `assembleRelease`) |
| Python | .py file | On the phone |
| ZIP / HTML | .zip or .html | On the phone (WebView app) |

APKs are saved to `Download/MobileAndroidStudio`. Needs Android 10+ (generated web/Python apps: Android 8+).

## Studio mode setup
1. Make a **private** GitHub repo and add a README. Use a repo just for this: `project.zip` gets overwritten.
2. Create a fine-grained token for that repo only: Contents, Actions, Workflows = Read and write.
3. Zip your project folder, enter `user/repo` and the token, build.

The token is saved on the phone, encrypted with an Android Keystore key. Tap **Forget saved token** to remove it.

Unsigned release APKs are signed with a throwaway key, so a new release build may need the old app uninstalled first. They are not for the Play Store.

## No-code mode
Add text, buttons, image buttons, images, counters, variables and text boxes. Buttons can add to, set or reset a value, or show a message. A variable can follow a counter (times N, plus M). Write `{name}` in text to show a value.

## Python apps
Python (Pyodide) downloads from jsDelivr on first launch.
- `x = input("...")`: type in the box, tap Send.
- Keys: `keyboard`, `msvcrt` and `pynput.keyboard` are basic stand-ins. Tap **Keyboard** for the on-screen keys. `curses` is not supported.
- Packages: missing imports are installed automatically (Pyodide builds, then pip via micropip). Only pure-Python or Pyodide-built packages work. A misspelled import could install an unrelated package with that name.
- Network: `urllib.request` and `requests` go through Android (20 MB per response, downloaded in full even with `stream=True`; proxy, certificate and `verify=` options are ignored). Other network libraries and raw sockets may not work.
- Custom icon: pick any image before building (Python and ZIP/HTML modes). For Studio projects, set the icon in the project.
- No tkinter, pygame windows or raw sockets.

## Debug vs release (Python / web)
Debug is debuggable, release is not. The signing keys in `app/src/main/assets/keys` are shared by every copy of this app, so don't publish apps signed with them.

## Building this app
- Android Studio or `./gradlew assembleDebug` / `./gradlew assembleRelease`
- Or Ubuntu without Gradle: `apt install aapt apksigner zipalign dalvik-exchange android-sdk-platform-23`, then `python3 build.py` (this also rebuilds the templates in `template/`)
- Icon: `python3 tools/make_icon.py`

#!/usr/bin/env python3
"""Builds the templates and the app with Ubuntu's Android tools (no Gradle needed)."""
import glob, os, shutil, subprocess as sp, zipfile
os.chdir(os.path.dirname(os.path.abspath(__file__)))
JAR = "/usr/lib/android-sdk/platforms/android-23/android.jar"
M = "app/src/main"
def run(*a): sp.run(a, check=True)
def javac(src, out, cp):
    run("javac", "--release", "8", "-nowarn", "-cp", cp, "-d", out, *glob.glob(src + "/**/*.java", recursive=True))
def package(manifest, res, assets, dexin, out):
    d = out + ".d"; os.makedirs(d)
    shutil.copy(manifest, d + "/AndroidManifest.xml"); manifest = d + "/AndroidManifest.xml"
    run("dalvik-exchange", "--dex", f"--output={d}/classes.dex", *dexin)
    a = ["aapt", "package", "-f", "-M", manifest, "-S", res, "-I", JAR, "-F", out + ".u"]
    if assets: a += ["-A", assets]
    run(*a)
    with zipfile.ZipFile(out + ".u", "a", zipfile.ZIP_DEFLATED) as z: z.write(d + "/classes.dex", "classes.dex")
    run("zipalign", "-f", "4", out + ".u", out)
shutil.rmtree("build", ignore_errors=True)
os.makedirs("build/rt"); os.makedirs("build/app")
javac("template/java", "build/rt", JAR)
for v in ("debug", "release"):
    package(f"template/AndroidManifest-{v}.xml", f"{M}/res", None, ["build/rt"], f"build/t-{v}.apk")
    shutil.copy(f"build/t-{v}.apk", f"{M}/assets/template-{v}.apk")
os.makedirs("build/stubs")
javac("stubs", "build/stubs", JAR)
javac(f"{M}/java", "build/app", "build/stubs:" + JAR)
m = open(f"{M}/AndroidManifest.xml").read().replace('android">', 'android" package="com.treyprograms.mobileandroidstudio" android:versionCode="6" android:versionName="1.5">\n    <uses-sdk android:minSdkVersion="29" android:targetSdkVersion="34" />', 1)
open("build/app-manifest.xml", "w").write(m)
package("build/app-manifest.xml", f"{M}/res", f"{M}/assets", ["build/app"], "build/aligned.apk")
if not os.path.exists("release.keystore"):
    run("keytool", "-genkeypair", "-keystore", "release.keystore", "-storepass", "android", "-keypass", "android",
        "-alias", "mas", "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000", "-dname", "CN=Mobile Android Studio")
run("apksigner", "sign", "--ks", "release.keystore", "--ks-pass", "pass:android",
    "--out", "MobileAndroidStudio.apk", "build/aligned.apk")
run("apksigner", "verify", "--min-sdk-version", "29", "MobileAndroidStudio.apk")
print("OK: MobileAndroidStudio.apk")
